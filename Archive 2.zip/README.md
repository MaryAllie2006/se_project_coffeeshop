# Triple Peaks Coffee Shop

This is the second project of the Software Engineering program at TripleTen. It was created using HTML and CSS, based on the design brief.

## Project features

- Semantic HTML5
- Flexbox
- Positioning
- Flat BEM file structure
- A custom form
- CSS animation and transform

## Plan on improving the project

To improve the webpage further I would add a more interesting layout of the Recipes Section. The header should be more captivating, the font is very bland. I also think the videos should be more distinct from each other more and their captions in a larger font size. 
